﻿using FluentAssertions;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Windows;
using System;

namespace NaploTeszt
{
    public class Tests
    {
        private readonly WindowsDriver<WindowsElement> _driver;

        public Tests()
        {
            
             var options = new AppiumOptions();

            options.AddAdditionalCapability(
                "app",
                @"C:\Users\Asus2026\Downloads\naplo\naplo\naplo\bin\Debug\net10.0-windows\naplo.exe");

            options.AddAdditionalCapability(
                "deviceName",
                "WindowsPC");

            _driver = new WindowsDriver<WindowsElement>(
                new Uri("http://127.0.0.1:4723"),
                options);

            _driver.Manage().Timeouts().ImplicitWait =
                TimeSpan.FromSeconds(10);
        }
        [Fact]

        public void Ujfoglalas_Test()
        {
            _driver.FindElementByName("Új adat hozzáadása").Click();

            _driver.SwitchTo().Window(_driver.WindowHandles.First());

            _driver.FindElementByAccessibilityId("txtNev").SendKeys("Tesyt Elek");

            _driver.FindElementByAccessibilityId("txtOsztaly").SendKeys("11A");

            _driver.FindElementByAccessibilityId("txtMatek").SendKeys("5");

            _driver.FindElementByAccessibilityId("txtFizika").SendKeys("2");

            _driver.FindElementByAccessibilityId("btnMentes").Click();

            

        }
    }
}