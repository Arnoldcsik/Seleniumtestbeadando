﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace naplo
{
    /// <summary>
    /// Interaction logic for UjTanuloWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        ObservableCollection<Tanulo> tanulok = new ObservableCollection<Tanulo>();

        public MainWindow()
        {
            InitializeComponent();

            
            osztalyzatok.ItemsSource = tanulok;

            
            tanulok.Add(new Tanulo { nev = "Kiss Péter", osztaly = "10A", matek = 4, fizika = 5 });
            tanulok.Add(new Tanulo { nev = "Nagy Anna", osztaly = "10A", matek = 5, fizika = 4 });
        }

        
        private void UjHozzadas_Click(object sender, RoutedEventArgs e)
        {
            UjTanuloWindow ablak = new UjTanuloWindow();

            if (ablak.ShowDialog() == true)
            {
                tanulok.Add(ablak.UjTanulo);
            }
        }

       
        private void Torles_Click(object sender, RoutedEventArgs e)
        {
            if (osztalyzatok.SelectedItem is Tanulo kivalasztott)
            {
                tanulok.Remove(kivalasztott);
            }
            else
            {
                MessageBox.Show("Nincs kiválasztott elem!");
            }
        }
    }
}