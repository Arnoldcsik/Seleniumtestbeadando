﻿using System;
using System.Collections.Generic;
using System.Text;

namespace naplo
{
    public class Tanulo
    {
        public string nev { get; set; }
        public string osztaly { get; set; }
        public int matek { get; set; }
        public int fizika { get; set; }

        public double atlag
        {
            get { return (matek + fizika) / 2.0; }
        }
    }
}
