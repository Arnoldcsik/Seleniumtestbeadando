﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace naplo
{
    /// <summary>
    /// Interaction logic for UjTanuloWindow.xaml
    /// </summary>
    public partial class UjTanuloWindow : Window
    {
        public Tanulo UjTanulo { get; private set; }

        public UjTanuloWindow()
        {
            InitializeComponent();
        }

        private void Mentes_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UjTanulo = new Tanulo
                {
                    nev = tbNev.Text,
                    osztaly = tbOsztaly.Text,
                    matek = int.Parse(tbMatek.Text),
                    fizika = int.Parse(tbFizika.Text)
                };

                DialogResult = true;
            }
            catch
            {
                MessageBox.Show("Hibás adatbevitel!");
            }
        }
    }
}
